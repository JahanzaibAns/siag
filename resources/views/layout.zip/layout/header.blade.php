<!DOCTYPE html>
<html class="no-js" lang="en">
  <head>
    <!-- Meta Tags -->
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="SIAG - Sindh Institute of Advanced Endoscopy and Gastroenterology">
    <meta name="description" content="@yield('meta_description', 'SIAG provides world-class gastroenterology and endoscopy care, training, and research in Karachi. Free advanced GI diagnostics and procedures at Civil Hospital.')">
    <!-- Favicon Icon -->
    <link rel="icon" href="{{asset('assets/img/cropped-SIAG-final-logo-1-32x32.webp')}}" sizes="32x32" />
    <link rel="icon" href="{{asset('assets/img/cropped-SIAG-final-logo-1-192x192.webp')}}" sizes="192x192" />
    <link rel="apple-touch-icon" href="{{asset('assets/img/cropped-SIAG-final-logo-1-180x180.webp')}}" />
    <!-- Site Title -->
    <title>@yield('title', 'SIAG – Sindh Institute of Advanced Endoscopy & Gastroenterology')</title>
    <link rel="stylesheet" href="{{asset('assets/css/bootstrap.min.css')}}">
    <link rel="stylesheet" href="{{asset('assets/css/fontawesome.min.css')}}">
    <link rel="stylesheet" href="{{asset('assets/css/animate.css')}}">
    <link rel="stylesheet" href="{{asset('assets/css/odometer.css')}}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.css" />
    <link rel="stylesheet" href="{{asset('assets/css/slick.min.css')}}">
    <link rel="stylesheet" href="{{asset('assets/css/style.css')}}">
  </head>
  <body>
    <div class="cs_preloader">
      <div class="cs_preloader_in">
        <div class="cs_wave_first">
          <svg enable-background="new 0 0 300.08 300.08" viewBox="0 0 300.08 300.08" xmlns="http://www.w3.org/2000/svg"><path d="m293.26 184.14h-82.877l-12.692-76.138c-.546-3.287-3.396-5.701-6.718-5.701-.034 0-.061 0-.089 0-3.369.027-6.199 2.523-6.677 5.845l-12.507 87.602-14.874-148.69c-.355-3.43-3.205-6.056-6.643-6.138-.048 0-.096 0-.143 0-3.39 0-6.274 2.489-6.752 5.852l-19.621 137.368h-9.405l-12.221-42.782c-.866-3.028-3.812-5.149-6.8-4.944-3.13.109-5.777 2.332-6.431 5.395l-8.941 42.332h-73.049c-3.771 0-6.82 3.049-6.82 6.82 0 3.778 3.049 6.82 6.82 6.82h78.566c3.219 0 6.002-2.251 6.67-5.408l4.406-20.856 6.09 21.313c.839 2.939 3.526 4.951 6.568 4.951h20.46c3.396 0 6.274-2.489 6.752-5.845l12.508-87.596 14.874 148.683c.355 3.437 3.205 6.056 6.643 6.138h.143c3.39 0 6.274-2.489 6.752-5.845l14.227-99.599 6.397 38.362c.546 3.287 3.396 5.702 6.725 5.702h88.66c3.771 0 6.82-3.049 6.82-6.82-.001-3.772-3.05-6.821-6.821-6.821z"></path></svg>
        </div>
        <div class="cs_wave_second">
          <svg enable-background="new 0 0 300.08 300.08" viewBox="0 0 300.08 300.08" xmlns="http://www.w3.org/2000/svg"><path d="m293.26 184.14h-82.877l-12.692-76.138c-.546-3.287-3.396-5.701-6.718-5.701-.034 0-.061 0-.089 0-3.369.027-6.199 2.523-6.677 5.845l-12.507 87.602-14.874-148.69c-.355-3.43-3.205-6.056-6.643-6.138-.048 0-.096 0-.143 0-3.39 0-6.274 2.489-6.752 5.852l-19.621 137.368h-9.405l-12.221-42.782c-.866-3.028-3.812-5.149-6.8-4.944-3.13.109-5.777 2.332-6.431 5.395l-8.941 42.332h-73.049c-3.771 0-6.82 3.049-6.82 6.82 0 3.778 3.049 6.82 6.82 6.82h78.566c3.219 0 6.002-2.251 6.67-5.408l4.406-20.856 6.09 21.313c.839 2.939 3.526 4.951 6.568 4.951h20.46c3.396 0 6.274-2.489 6.752-5.845l12.508-87.596 14.874 148.683c.355 3.437 3.205 6.056 6.643 6.138h.143c3.39 0 6.274-2.489 6.752-5.845l14.227-99.599 6.397 38.362c.546 3.287 3.396 5.702 6.725 5.702h88.66c3.771 0 6.82-3.049 6.82-6.82-.001-3.772-3.05-6.821-6.821-6.821z"></path></svg>
        </div>
      </div>
    </div>
    <!-- Start Header Section -->
    <header class="cs_site_header cs_style_1 cs_primary_color cs_sticky_header cs_white_bg">
      <div class="cs_top_header cs_blue_bg cs_white_color">
        <div class="container">
          <div class="cs_top_header_in">
            <div class="cs_top_header_left">
              <ul class="cs_header_contact_list cs_mp_0">
                <li>
                  <i class="fa-solid fa-envelope"></i>
                  <a href="mailto:contact@siagpk.org">contact@siagpk.org</a>
                </li>
                <li>
                  <i class="fa-solid fa-phone"></i>
                  <a href="tel:021327505246">021-32750524-6</a>
                </li>
              </ul>
            </div>
            <div class="cs_top_header_right">
              <div class="cs_social_btns cs_style_1">
                <a href="https://www.facebook.com/siagpk" class="cs_center" target="_blank"><i class="fa-brands fa-facebook-f"></i></a>
                <a href="https://x.com/SIAGPK" class="cs_center" target="_blank"><i class="fa-brands fa-twitter"></i></a>
                <a href="https://www.instagram.com/siagpk/" class="cs_center" target="_blank"><i class="fa-brands fa-instagram"></i></a>
                <a href="https://www.youtube.com/@SIAGPakistan" class="cs_center" target="_blank"><i class="fa-brands fa-youtube"></i></a>
                <a href="https://www.linkedin.com/company/sindh-institute-of-advanced-endoscopy-and-gastroenterology/" class="cs_center" target="_blank"><i class="fa-brands fa-linkedin"></i></a>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="cs_main_header">
        <div class="container">
          <div class="cs_main_header_in">
            <div class="cs_main_header_left">
              <a class="cs_site_branding" href="{{ route('index') }}">
                <img src="{{asset('assets/img/logo.webp')}}" alt="Logo">
              </a>
            </div>
            <div class="cs_main_header_right">
              <div class="cs_nav cs_primary_color">
                <ul class="cs_nav_list">
                  <li> <a href="{{ route('index') }}">Home</a></li>
                  <li class="menu-item-has-children">
                    <a href="javascript:void(0);">About Us</a>
                    <ul>
                      <li><a href="{{ route('our.doctors') }}">Our Doctors</a></li>
                      <li><a href="{{ route('our.story') }}">Our Story</a></li>
                      <li><a href="{{ route('leadership') }}">Leadership</a></li>
                      <li><a href="{{ route('mission.vision') }}">Mission & Vision</a></li>
                      <li><a href="{{ route('departments') }}">Departments</a></li>
                    </ul>
                  </li>
                  <li class="menu-item-has-children">
                    <a href="javascript:void(0);">Patients</a>
                    <ul>
                      <li><a href="{{ route('services')}}">Services</a></li>
                      <li><a href="{{ route('appointments') }}">Appointment</a></li>
                      <!-- <li><a href="javascript:void(0);">Pancreatic Clinic</a></li> -->
                    </ul>
                  </li>
                  <li class="menu-item-has-children">
                    <a href="javascript:void(0);">Academics</a>
                    <ul>
                      <li><a href="{{ route('careers')}}">Careers</a></li>
                      <li><a href="{{ route('workshop')}}">Workshops</a></li>
                      <li><a href="{{ route('trainings')}}">Trainings</a></li>
                      <li><a href="{{ route('sessions')}}">Sessions</a></li>
                      <!-- <li><a href="javascript:void(0);">Fellowship Programs</a></li> -->
                    </ul>
                  </li>
                  <li class="menu-item-has-children">
                    <a href="">Media & Gallery</a>
                    <ul>
                      <li><a href="{{ route('newsletter')}}">Newsletter</a></li>
                      <li><a href="{{ route('events')}}">Events</a></li>
                      <li><a href="{{ route('images')}}">Images</a></li>
                      <li><a href="{{ route('videos')}}">Videos</a></li>
                    </ul>
                  </li>
                  <li><a href="{{ route('tenders') }}">Tenders</a></li>
                  <li><a href="{{ route('contact') }}">Contact Us</a></li>
                </ul>
              </div>
              <a href="{{ route('donate') }}" class="cs_btn cs_style_1 cs_color_1">
                <span>Donate Now </span>
                <i class="fa-solid fa-angles-right"></i>
              </a>
            </div>
          </div>
        </div>
      </div>
    </header>