@extends('layout.main')
@section('title')
SIAG – Sindh Institute of Advanced Endoscopy & Gastroenterology | Karachi
@endsection
@section('meta_description')
SIAG offers free world-class gastroenterology, endoscopy, and hepatology care at Civil Hospital Karachi. Advanced diagnostics, ERCP, EUS, training & research.
@endsection
@section('content')
    <section class="position-relative cs_hero cs_style_1 cs_center overflow-hidden">
      <video autoplay muted loop playsinline class="cs_bg_video">
        <source src="https://www.koder360.com/siag/public/assets/video/banner.mp4" type="video/mp4">
        Your browser does not support the video tag.
      </video>
    
      <div class="cs_video_overlay"></div>
    
      <div class="container position-relative">
        <div class="cs_hero_text">
          <div class="cs_hero_text_in">
            
            <h1 class="cs_hero_title">
              Built with <span>Excellence</span> to Heal.
            </h1>
    
            <p class="cs_hero_subtitle">
              World-class healthcare with advanced technology and compassionate experts dedicated to your well-being.
            </p>
    
            <div class="cs_hero_btns">
              <a href="{{ route('contact') }}" class="cs_btn cs_style_1 cs_color_1">
                <span>Contact Now </span>
                <i class="fa-solid fa-angles-right"></i>
              </a>
    
              <a href="{{ route('our.story') }}" class="cs_btn cs_style_1 cs_color_2">
                <span>Discover More </span>
                <i class="fa-solid fa-angles-right"></i>
              </a>
            </div>
    
          </div>
        </div>
      </div>
    </section>
    
    
    <!-- End Hero Section -->

    <!-- Start About Section -->
    <section class="cs_about cs_style_1 position-relative">
      <div class="cs_height_120 cs_height_lg_80"></div>
      <div class="container">
        <div class="row align-items-center cs_gap_y_40">
          <div class="col-lg-6">
            <div class="cs_about_thumb">
              <div class="cs_about_thumb_1">
                <img src="{{asset('assets/img/about.jpeg')}}" alt="">
              </div>
              <div class="cs_about_thumb_2">
                <img src="{{asset('assets/img/Mission-and-Vision-580x348.jpeg')}}" alt="About Image">
                <img src="{{asset('assets/img/icons/about_shape_1.png')}}" alt="Shape Image" class="cs_about_thumb_shape_2">
              </div>
              <div class="cs_experience_box cs_center">
                <p class="cs_experience_box_number">18+</p>
                <p class="cs_experience_box_title">Years of Service</p>
              </div>
            </div>
          </div>
          <div class="col-lg-6 wow fadeInRight" data-wow-duration="0.9s" data-wow-delay="0.25s">
            <div class="cs_about_content">
              <div class="cs_section_heading cs_style_1">
                <p class="cs_section_subtitle cs_accent_color">
                  <span class="cs_shape_left"></span>
                  OUR STORY
                </p>
                <h2 class="cs_section_title">Pakistan's First Dedicated Endoscopy Institute.</h2>
              </div>
              <p class="cs_about_text">Founded in 2006 by Prof. M Saeed Quraishy & Dr. Saad Khalid Niaz at Civil Hospital Karachi. What began as a two-room unit is now a pioneering center of excellence—making advanced GI care a right, not a privilege.</p>
              <div class="row cs_gap_y_30">
                <div class="col-sm-6">
                  <div class="cs_iconbox cs_style_1">
                    <div class="cs_iconbox_head">
                      <div class="cs_iconbox_icon cs_center">
                        <img src="{{asset('assets/img/icons/about_icon_1.png')}}" alt="Heart icon representing compassion">
                      </div>
                      <h3 class="cs_iconbox_title m-0">Compassion</h3>
                    </div>
                    <p class="cs_iconbox_subtitle mb-0">We serve every patient with dignity and respect.</p>
                  </div>
                </div>
                <div class="col-sm-6">
                  <div class="cs_iconbox cs_style_1">
                    <div class="cs_iconbox_head">
                      <div class="cs_iconbox_icon cs_center">
                        <img src="{{asset('assets/img/icons/about_icon_2.png')}}" alt="Shield icon representing excellence">
                      </div>
                      <h3 class="cs_iconbox_title m-0">Excellence</h3>
                    </div>
                    <p class="cs_iconbox_subtitle mb-0">We pioneer advanced care and research.</p>
                  </div>
                </div>
              </div>
              <div class="cs_about_iconbox">
                <div class="cs_about_iconbox_icon cs_center">
                  <i class="fa-regular fa-circle-check"></i>
                </div>
                <p class="cs_about_iconbox_subtitle">Where service meets innovation. <a href="{{ route('our.story') }}">READ MORE +</a></p>
              </div>
              <a href="{{ route('our.story') }}" class="cs_btn cs_style_1 cs_color_1">
                <span>About More </span>
                <i class="fa-solid fa-angles-right"></i>
              </a>
            </div>
          </div>
        </div>
      </div>
      <div class="cs_section_img"><img src="{{asset('assets/img/about_section_img_1.png')}}" alt=""></div>
      <div class="cs_height_120 cs_height_lg_80"></div>
    </section>
    <!-- End About Section -->
    <!-- Start Counter -->
    <div class="cs_counter_area cs_gray_bg">
      <div class="container">
        <div class="cs_counter_content cs_blue_bg">
          <div class="cs_counter_shape position-absolute">
            <img src="{{asset('assets/img/counter_shape.png')}}" alt="Shape">
          </div>
          <div class="cs_counter_1_wrap">
            <div class="cs_counter cs_style_1">
              <div class="cs_counter_icon cs_center">
                <i class="fas fa-stethoscope"></i>
              </div>
              <div class="cs_counter_nmber"><span data-count-to="4273" class="odometer"></span>+</div>
              <p class="cs_counter_title mb-0">Colonoscopies</p>
            </div>
            <div class="cs_counter cs_style_1">
              <div class="cs_counter_icon cs_center">
                <i class="fas fa-procedures"></i>
              </div>
              <div class="cs_counter_nmber"><span data-count-to="9852" class="odometer"></span>+</div>
              <p class="cs_counter_title mb-0">OGD Procedures</p>
            </div>
            <div class="cs_counter cs_style_1">
              <div class="cs_counter_icon cs_center">
                <i class="fas fa-x-ray"></i>
              </div>
              <div class="cs_counter_nmber"><span data-count-to="7138" class="odometer"></span>+</div>
              <p class="cs_counter_title mb-0">ERCPs</p>
            </div>
            <div class="cs_counter cs_style_1">
              <div class="cs_counter_icon cs_center">
              <i class="fas fa-magnet"></i>
              </div>
              <div class="cs_counter_nmber"><span data-count-to="1780" class="odometer"></span>+</div>
              <p class="cs_counter_title mb-0">EUS Procedures</p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- End Counter -->
    <!-- Start Service Section -->
    <section class="cs_gray_bg">
        <div class="cs_height_110 cs_height_lg_70"></div>
        <div class="container">
            <div class="cs_section_heading cs_style_1 cs_type_1">
            <div class="cs_section_heading_left">
                <p class="cs_section_subtitle cs_accent_color wow fadeInLeft" data-wow-duration="0.9s" data-wow-delay="0.25s">
                <span class="cs_shape_left"></span>
                OUR SERVICES
                </p>
                <h2 class="cs_section_title">Advanced Gastroenterology & Endoscopy</h2>
            </div>
            <div class="cs_section_heading_right">State-of-the-art diagnostic and therapeutic procedures with compassionate care.</div>
            </div>
            <div class="cs_height_50 cs_height_lg_50"></div>
            <div class="row cs_row_gap_30 cs_gap_y_30">
            <div class="col-xl-3 col-lg-4 col-sm-6">
                <div class="cs_iconbox cs_style_2 cs_radius_15 cs_hover_layer_2">
                <div class="cs_iconbox_overlay cs_bg_filed" data-src="{{asset('assets/img/service_bg.jpg')}}"></div>
                <div class="cs_iconbox_shape"></div>
                <div class="cs_iconbox_header d-flex align-items-center justify-content-between">
                    <div class="cs_iconbox_icon cs_center">
                    <!-- <img src="{{asset('assets/img/icons/service_icon_1.png')}}" alt="Service Icon"> -->
                    <i class="fas fa-stethoscope"></i>
                    </div>
                    <h3 class="iconbox_index">01</h3>
                </div>
                <h3 class="cs_iconbox_title"><a href="{{ route('ogd.endoscopy') }}">OGD (Endoscopy)</a></h3>
                <p class="cs_iconbox_subtitle m-0">Upper GI diagnostic and therapeutic procedures</p>
                </div>
            </div>
            <div class="col-xl-3 col-lg-4 col-sm-6">
                <div class="cs_iconbox cs_style_2 cs_radius_15">
                <div class="cs_iconbox_overlay cs_bg_filed" data-src="{{asset('assets/img/service_bg.jpg')}}"></div>
                <div class="cs_iconbox_shape"></div>
                <div class="cs_iconbox_header d-flex align-items-center justify-content-between">
                    <div class="cs_iconbox_icon cs_center">
                    <!-- <img src="{{asset('assets/img/icons/service_icon_2.png')}}" alt="Service Icon"> -->
                    <i class="fa-solid fa-arrow-right-arrow-left"></i>
                    </div>
                    <h3 class="iconbox_index">02</h3>
                </div>
                <h3 class="cs_iconbox_title"><a href="{{ route('colonoscopy') }}">Colonoscopy</a></h3>
                <p class="cs_iconbox_subtitle m-0">Complete large bowel examination</p>
                </div>
            </div>
            <div class="col-xl-3 col-lg-4 col-sm-6">
                <div class="cs_iconbox cs_style_2 cs_radius_15">
                <div class="cs_iconbox_overlay cs_bg_filed" data-src="{{asset('assets/img/service_bg.jpg')}}"></div>
                <div class="cs_iconbox_shape"></div>
                <div class="cs_iconbox_header d-flex align-items-center justify-content-between">
                    <div class="cs_iconbox_icon cs_center">
                    <!-- <img src="{{asset('assets/img/icons/service_icon_3.png')}}" alt="Service Icon"> -->
                    <i class="fa-solid fa-x-ray"></i>
                    </div>
                    <h3 class="iconbox_index">03</h3>
                </div>
                <h3 class="cs_iconbox_title"><a href="{{ route('ercp') }}">ERCP</a></h3>
                <p class="cs_iconbox_subtitle m-0">Bile duct and pancreatic interventions</p>
                </div>
            </div>
            <div class="col-xl-3 col-lg-4 col-sm-6">
                <div class="cs_iconbox cs_style_2 cs_radius_15">
                <div class="cs_iconbox_overlay cs_bg_filed" data-src="{{asset('assets/img/service_bg.jpg')}}"></div>
                <div class="cs_iconbox_shape"></div>
                <div class="cs_iconbox_header d-flex align-items-center justify-content-between">
                    <div class="cs_iconbox_icon cs_center">
                    <!-- <img src="{{asset('assets/img/icons/service_icon_4.png')}}" alt="Service Icon"> -->
                    <i class="fa-solid fa-bolt"></i>
                    </div>
                    <h3 class="iconbox_index">04</h3>
                </div>
                <h3 class="cs_iconbox_title"><a href="{{ route('eswl') }}">ESWL</a></h3>
                <p class="cs_iconbox_subtitle m-0">Shock wave lithotripsy for stones</p>
                </div>
            </div>
            <div class="col-xl-3 col-lg-4 col-sm-6">
                <div class="cs_iconbox cs_style_2 cs_radius_15">
                <div class="cs_iconbox_overlay cs_bg_filed" data-src="{{asset('assets/img/service_bg.jpg')}}"></div>
                <div class="cs_iconbox_shape"></div>
                <div class="cs_iconbox_header d-flex align-items-center justify-content-between">
                    <div class="cs_iconbox_icon cs_center">
                    <!-- <img src="{{asset('assets/img/icons/service_icon_5.png')}}" alt="Service Icon"> -->
                    <i class="fa-solid fa-magnifying-glass"></i>
                    </div>
                    <h3 class="iconbox_index">05</h3>
                </div>
                <h3 class="cs_iconbox_title"><a href="{{ route('spyglass') }}">Spyglass</a></h3>
                <p class="cs_iconbox_subtitle m-0">Cholangioscopy for bile duct visualization</p>
                </div>
            </div>
            <div class="col-xl-3 col-lg-4 col-sm-6">
                <div class="cs_iconbox cs_style_2 cs_radius_15">
                <div class="cs_iconbox_overlay cs_bg_filed" data-src="{{asset('assets/img/service_bg.jpg')}}"></div>
                <div class="cs_iconbox_shape"></div>
                <div class="cs_iconbox_header d-flex align-items-center justify-content-between">
                    <div class="cs_iconbox_icon cs_center">
                    <!-- <img src="{{asset('assets/img/icons/service_icon_6.png')}}" alt="Service Icon"> -->
                    <i class="fa-solid fa-wave-square"></i>
                    </div>
                    <h3 class="iconbox_index">06</h3>
                </div>
                <h3 class="cs_iconbox_title"><a href="{{ route('eus') }}">EUS</a></h3>
                <p class="cs_iconbox_subtitle m-0">Endoscopic ultrasound imaging</p>
                </div>
            </div>
            <div class="col-xl-3 col-lg-4 col-sm-6">
                <div class="cs_iconbox cs_style_2 cs_radius_15">
                <div class="cs_iconbox_overlay cs_bg_filed" data-src="{{asset('assets/img/service_bg.jpg')}}"></div>
                <div class="cs_iconbox_shape"></div>
                <div class="cs_iconbox_header d-flex align-items-center justify-content-between">
                    <div class="cs_iconbox_icon cs_center">
                    <!-- <img src="{{asset('assets/img/icons/service_icon_7.png')}}" alt="Service Icon"> -->
                    <i class="fa-solid fa-fire"></i>
                    </div>
                    <h3 class="iconbox_index">07</h3>
                </div>
                <h3 class="cs_iconbox_title"><a href="{{ route('eus.rfa') }}">EUS RFA</a></h3>
                <p class="cs_iconbox_subtitle m-0">Radiofrequency ablation guided by EUS</p>
                </div>
            </div>
            <div class="col-xl-3 col-lg-4 col-sm-6">
                <div class="cs_iconbox cs_style_2 cs_radius_15">
                <div class="cs_iconbox_overlay cs_bg_filed" data-src="{{asset('assets/img/service_bg.jpg')}}"></div>
                <div class="cs_iconbox_shape"></div>
                <div class="cs_iconbox_header d-flex align-items-center justify-content-between">
                    <div class="cs_iconbox_icon cs_center">
                    <!-- <img src="{{asset('assets/img/icons/service_icon_8.png')}}" alt="Service Icon"> -->
                    <i class="fa-solid fa-chart-line"></i>
                    </div>
                    <h3 class="iconbox_index">08</h3>
                </div>
                  <h3 class="cs_iconbox_title"><a href="{{ route('esophageal.manometry') }}">Esophageal Manometry</a></h3>
                <p class="cs_iconbox_subtitle m-0">Motility and pressure studies</p>
                </div>
            </div>
            </div>
            <div class="cs_service_footer">
            <div class="cs_service_footer_icon">
                <img src="{{asset('assets/img/icons/service_footer_icon_1.png')}}" alt="Icon">
            </div>
            <div class="cs_service_footer_text cs_medium">
                Advanced care with dignity—high-quality GI treatment accessible to everyone. <a href="{{ route('services')}}">VIEW ALL SERVICES <i class="fa-solid fa-angles-right"></i></a>
            </div>
            </div>
        </div>
        <div class="cs_height_120 cs_height_lg_80"></div>
    </section>
    <!-- End Service Section -->
    <!-- Start Team Section -->
    <section>
      <div class="cs_height_110 cs_height_lg_70"></div>
      <div class="container">
        <div class="cs_section_heading cs_style_1 text-center">
          <p class="cs_section_subtitle cs_accent_color wow fadeInUp" data-wow-duration="0.9s" data-wow-delay="0.25s">
            <span class="cs_shape_left"></span>OUR TEAM MEMBER<span class="cs_shape_right"></span>
          </p>
          <h2 class="cs_section_title">Meet Our Specialist This <br>Doctor Meeting</h2>
        </div>
        <div class="cs_height_50 cs_height_lg_50"></div>
        <div class="cs_slider cs_style_1 cs_slider_gap_24">
          <div class="cs_slider_container" data-autoplay="0" data-loop="1" data-speed="600" data-center="0"
            data-variable-width="0" data-slides-per-view="responsive" data-xs-slides="1" data-sm-slides="2" data-md-slides="3" data-lg-slides="4" data-add-slides="4">
            <div class="cs_slider_wrapper">
              <div class="cs_slide">
                <div class="cs_team cs_style_1 cs_blue_bg">
                  <div class="cs_team_shape cs_accent_bg"></div>
                  <a href="{{ route('dr-saad-khalid-niaz') }}" class="cs_team_thumbnail">
                    <img src="{{asset('assets/img/team/dr-saad.jpg')}}" alt="Team Thumbnail">
                  </a>
                  <div class="cs_team_bio">
                    <h3 class="cs_team_title cs_extra_bold mb-0"><a href="{{ route('dr-saad-khalid-niaz') }}">Dr. Saad Khalid Niaz</a></h3>
                    <p class="cs_team_subtitle">Gastroenterologist & Hepatologist</p>
                  </div>
                </div>
              </div>
              <div class="cs_slide">
                <div class="cs_team cs_style_1 cs_blue_bg">
                  <div class="cs_team_shape cs_accent_bg"></div>
                  <a href="{{ route('dr-sajida-qureshi') }}" class="cs_team_thumbnail">
                    <img src="{{asset('assets/img/team/team2.jpeg')}}" alt="Team Thumbnail">
                  </a>
                  <div class="cs_team_bio">
                    <h3 class="cs_team_title cs_extra_bold mb-0"><a href="{{ route('dr-sajida-qureshi') }}">Dr. Sajida Qureshi</a></h3>
                    <p class="cs_team_subtitle">Upper GI & Bariatric Surgeon</p>
                  </div>
                </div>
              </div>
              <div class="cs_slide">
                <div class="cs_team cs_style_1 cs_blue_bg">
                  <div class="cs_team_shape cs_accent_bg"></div>
                  <a href="{{ route('dr-babar-matin') }}" class="cs_team_thumbnail">
                    <img src="{{asset('assets/img/team/dr-babar.jpg')}}" alt="Team Thumbnail">
                  </a>
                  <div class="cs_team_bio">
                    <h3 class="cs_team_title cs_extra_bold mb-0"><a href="{{ route('dr-babar-matin') }}">Dr. Babar Matin</a></h3>
                    <p class="cs_team_subtitle">Incharge GI MOTILITY</p>
                  </div>
                </div>
              </div>
              <div class="cs_slide">
                <div class="cs_team cs_style_1 cs_blue_bg">
                  <div class="cs_team_shape cs_accent_bg"></div>
                  <a href="{{ route('dr-shanil-kadir') }}" class="cs_team_thumbnail">
                    <img src="{{asset('assets/img/team/team4.jpeg')}}" alt="Team Thumbnail">
                  </a>
                  <div class="cs_team_bio">
                    <h3 class="cs_team_title cs_extra_bold mb-0"><a href="{{ route('dr-shanil-kadir') }}">Dr. Shanil Kadir</a></h3>
                    <p class="cs_team_subtitle">FCPS (General Surgery)</p>
                  </div>
                </div>
              </div>
              <div class="cs_slide">
                <div class="cs_team cs_style_1 cs_blue_bg">
                  <div class="cs_team_shape cs_accent_bg"></div>
                  <a href="{{ route('dr-aftab-leghari') }}" class="cs_team_thumbnail">
                    <img src="{{asset('assets/img/team/team5.jpeg')}}" alt="Team Thumbnail">
                  </a>
                  <div class="cs_team_bio">
                    <h3 class="cs_team_title cs_extra_bold mb-0"><a href="{{ route('dr-aftab-leghari') }}">Dr. Aftab Leghari</a></h3>
                    <p class="cs_team_subtitle">FCPS (General Surgery)</p>
                  </div>
                </div>
              </div>
              <div class="cs_slide">
                <div class="cs_team cs_style_1 cs_blue_bg">
                  <div class="cs_team_shape cs_accent_bg"></div>
                  <a href="{{ route('dr-shanil-kadir') }}" class="cs_team_thumbnail">
                    <img src="{{asset('assets/img/team/team6.jpeg')}}" alt="Team Thumbnail">
                  </a>
                  <div class="cs_team_bio">
                    <h3 class="cs_team_title cs_extra_bold mb-0"><a href="{{ route('dr-shanil-kadir') }}">Dr. Shanil Kadir</a></h3>
                    <p class="cs_team_subtitle">CCT G(I)M & Gastroenterology</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="cs_pagination cs_style_2"></div>
        </div>
      </div>
      <div class="cs_height_120 cs_height_lg_80"></div>
      <hr>
    </section>
    <!-- End Team Section -->
    <!-- Start Why Choose Us Section -->
    <section class="cs_gray_bg cs_bg_filed" data-src="{{asset('assets/img/banners/why-choose-banner.jpeg')}}">
      <div class="cs_height_110 cs_height_lg_70"></div>
      <div class="container">
        <div class="row">
          <div class="col-lg-8">
            <div class="cs_section_heading cs_style_1">
              <p class="cs_section_subtitle cs_accent_color wow fadeInLeft" data-wow-duration="0.9s" data-wow-delay="0.25s"><span class="cs_shape_left"></span> WHY CHOOSE US</p>
              <h2 class="cs_section_title">Excellence in Gastrointestinal <br>Care & Treatment.</h2>
            </div>
            <div class="cs_height_50 cs_height_lg_50"></div>
          </div>
        </div>
        <div class="row">
          <div class="col-xxl-7 col-xl-8 col-lg-9">
            <div class="cs_service_wrapper">
              <div class="cs_service_list">
                <div class="cs_iconbox cs_style_3">
                  <div class="cs_iconbox_icon cs_center cs_radius_5">
                    <img src="{{asset('assets/img/icons/service_icon_9.png')}}" alt="Icon">
                  </div>
                  <div class="cs_iconbox_text">
                    <h3 class="cs_iconbox_title">Advanced Technology</h3>
                    <p class="cs_iconbox_subtitle">State-of-the-art endoscopic equipment</p>
                  </div>
                </div>
                <div class="cs_iconbox cs_style_3">
                  <div class="cs_iconbox_icon cs_center cs_radius_5">
                    <img src="{{asset('assets/img/icons/service_icon_10.png')}}" alt="Icon">
                  </div>
                  <div class="cs_iconbox_text">
                    <h3 class="cs_iconbox_title">Emergency &amp; Urgent Care</h3>
                    <p class="cs_iconbox_subtitle">Urgent GI care when you need it</p>
                  </div>
                </div>
                <div class="cs_iconbox cs_style_3">
                  <div class="cs_iconbox_icon cs_center cs_radius_5">
                    <img src="{{asset('assets/img/icons/service_icon_11.png')}}" alt="Icon">
                  </div>
                  <div class="cs_iconbox_text">
                    <h3 class="cs_iconbox_title">Compassionate Care</h3>
                    <p class="cs_iconbox_subtitle">Serving with dignity and empathy</p>
                  </div>
                </div>
                <div class="cs_iconbox cs_style_3">
                  <div class="cs_iconbox_icon cs_center cs_radius_5">
                    <img src="{{asset('assets/img/icons/service_icon_12.png')}}" alt="Icon">
                  </div>
                  <div class="cs_iconbox_text">
                    <h3 class="cs_iconbox_title">Expert Specialists</h3>
                    <p class="cs_iconbox_subtitle">UK-trained gastroenterologists</p>
                  </div>
                </div>
                <div class="cs_iconbox cs_style_3">
                  <div class="cs_iconbox_icon cs_center cs_radius_5">
                    <img src="{{asset('assets/img/icons/service_icon_13.png')}}" alt="Icon">
                  </div>
                  <div class="cs_iconbox_text">
                    <h3 class="cs_iconbox_title">Pioneering Research</h3>
                    <p class="cs_iconbox_subtitle">First dedicated endoscopy institute</p>
                  </div>
                </div>
                <div class="cs_iconbox cs_style_3">
                  <div class="cs_iconbox_icon cs_center cs_radius_5">
                    <img src="{{asset('assets/img/icons/service_icon_14.png')}}" alt="Icon">
                  </div>
                  <div class="cs_iconbox_text">
                    <h3 class="cs_iconbox_title">Free Treatment</h3>
                    <p class="cs_iconbox_subtitle">Care for underserved communities</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="cs_height_120 cs_height_lg_80"></div>
    </section>
    <!-- End Why Choose Us Section -->
    <!-- Start Projects Section -->
    <section class="cs_tabs">
      <div class="cs_height_110 cs_height_lg_70"></div>
      <div class="container">
        <div class="cs_section_heading cs_style_1 cs_type_1">
          <div class="cs_section_heading_left">
            <p class="cs_section_subtitle cs_accent_color wow fadeInLeft" data-wow-duration="0.9s" data-wow-delay="0.25s"><span class="cs_shape_left"></span>OUR DEPARTMENTS</p>
            <h2 class="cs_section_title">Primary Care Practices</h2>
          </div>
          
        </div>
        <div class="cs_height_50 cs_height_lg_50"></div>
      </div>
      <div class="cs_tab_body">
        <div class="container-fluide cs_tab active" id="dental">
          <div class="row cs_gap_y_30">
            <div class="col-lg-3">
              <div class="cs_card cs_style_1">
                <a href="{{ route('clinical.research.and.trials') }}" class="cs_card_thumbnail d-block">
                  <img src="{{asset('assets/img/departments/clinical-trails.jpeg')}}" alt="Project Image" class="w-100">
                </a>
                <div class="cs_card_info_wrapper">
                  <div class="cs_card_text">
                    <h3 class="cs_card_title"><a href="{{ route('clinical.research.and.trials') }}">Clinical Research and Trials</a></h3>
                    <p class="cs_card_subtitle mb-0">We businesss standard chunk of Ipsum used since is Agency & Star tup.</p>
                  </div>
                  <div class="cs_card_index cs_center rounded-circle">01</div>
                </div>
              </div>
            </div>
            <div class="col-lg-3">
              <div class="cs_card cs_style_1">
                <a href="{{ route('advanced.diagnostic.technologies') }}" class="cs_card_thumbnail d-block">
                  <img src="{{asset('assets/img/departments/diagnostic.jpeg')}}" alt="Project Image" class="w-100">
                </a>
                <div class="cs_card_info_wrapper">
                  <div class="cs_card_text">
                    <h3 class="cs_card_title"><a href="{{ route('advanced.diagnostic.technologies') }}">Advanced Diagnostic Technologies</a></h3>
                    <p class="cs_card_subtitle mb-0">We businesss standard chunk of Ipsum used since is Agency & Star tup.</p>
                  </div>
                  <div class="cs_card_index cs_center rounded-circle">02</div>
                </div>
              </div>
            </div>
            <div class="col-lg-3">
              <div class="cs_card cs_style_1">
                <a href="{{ route('endoscopy.unit') }}" class="cs_card_thumbnail d-block">
                  <img src="{{asset('assets/img/departments/endoscopy.jpeg')}}" alt="Project Image" class="w-100">
                </a>
                <div class="cs_card_info_wrapper">
                  <div class="cs_card_text">
                    <h3 class="cs_card_title"><a href="{{ route('endoscopy.unit') }}">Endoscopy Unit</a></h3>
                    <p class="cs_card_subtitle mb-0">We businesss standard chunk of Ipsum used since is Agency & Star tup.</p>
                  </div>
                  <div class="cs_card_index cs_center rounded-circle">03</div>
                </div>
              </div>
            </div>
            <div class="col-lg-3">
              <div class="cs_card cs_style_1">
                <a href="{{ route('innovation.and.technology.lab') }}" class="cs_card_thumbnail d-block">
                  <img src="{{asset('assets/img/departments/innovation.jpeg')}}" alt="Project Image" class="w-100">
                </a>
                <div class="cs_card_info_wrapper">
                  <div class="cs_card_text">
                    <h3 class="cs_card_title"><a href="{{ route('innovation.and.technology.lab') }}">Innovation and Technology Lab</a></h3>
                    <p class="cs_card_subtitle mb-0">We businesss standard chunk of Ipsum used since is Agency & Star tup.</p>
                  </div>
                  <div class="cs_card_index cs_center rounded-circle">04</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="cs_height_90 cs_height_lg_50"></div>
      <hr>
    </section>
    <!-- End Projects Section -->
    <!-- Start CTA Section -->
    <section class="cs_cta cs_style_2 cs_blue_bg cs_bg_filed cs_center" data-src="{{asset('assets/img/banners/video-sec-banner.jpeg')}}">
      <div class="container">
        <div class="row align-items-center cs_gap_y_40">
          <div class="col-lg-6">
            <div class="cs_cta_btn_wrapper wow zoomIn" data-wow-duration="0.9s" data-wow-delay="0.25s">
              <a href="https://www.youtube.com/embed/k0YfPtGyjPI?si=mUjqAtglV3Zh7Ht8" class="cs_video_open">
                <span class="cs_player_btn cs_center">
                  <span></span>
                </span>
                <span class="cs_play_btn_text">WATCH VIDEO</span>
              </a>
            </div>
          </div>
          <div class="col-lg-6">
            <div class="cs_cta_text">
              <div class="cs_section_heading cs_style_1">
                <p class="cs_section_subtitle cs_accent_color"><span class="cs_shape_left"></span>FEATURED VIDEO</p>
                <h2 class="cs_section_title cs_white_color">Transforming Vision into Reality</h2>
                <p class="cs_cta_subtitle cs_white_color">Witness the inspiring journey of SIAG—from a modest two-room unit to Pakistan's first dedicated endoscopy institute. See how Prof. M Saeed Quraishy and Dr. Saad Khalid Niaz are making advanced GI care accessible to all at Civil Hospital Karachi.</p>
                  <a href="https://www.youtube.com/embed/k0YfPtGyjPI?si=mUjqAtglV3Zh7Ht8" target="_blank" class="cs_btn cs_style_1 cs_color_3">
                    <span>Watch Video </span>
                    <i class="fa-solid fa-angles-right"></i>
                  </a>
              </div>
            </div>
          </div>
        </div>
        <div class="cs_cta_shape position-absolute">
          <img src="{{asset('assets/img/medical_brand.png')}}" alt="Medical Brand" class="cs_spinner_img">
        </div>
      </div>
    </section>
    <!-- End CTA Section -->
    <!-- Start Medical Tab Section -->
    <section>
      <div class="cs_height_110 cs_height_lg_70"></div>
      <div class="container">
        <div class="cs_section_heading cs_style_1 text-center">
          <p class="cs_section_subtitle cs_accent_color wow fadeInUp" data-wow-duration="0.9s" data-wow-delay="0.25s">
            <span class="cs_shape_left"></span>SERVICES WE PROVIDE<span class="cs_shape_right"></span>
          </p>
          <h2 class="cs_section_title">Our Focus Is On The <br> Patient</h2>
        </div>
        <div class="cs_height_50 cs_height_lg_50"></div>
        <div class="cs_tabs">
          <ul class="cs_tab_links cs_style_1 cs_bold">
            <li class="active">
              <a href="#brain_althim">
                <span class="cs_tab_link_icon cs_center"><img src="{{asset('assets/img/icons/tab_link_icon_1.png')}}" alt="Icon"></span>
                <span>Mission and Vision</span>
              </a>
            </li>
            <li>
              <a href="#emergency">
                <span class="cs_tab_link_icon cs_center"><img src="{{asset('assets/img/icons/counter_icon_4.png')}}" alt="Icon"></span>
                <span>Leadership</span>
              </a>
            </li>
            <li>
              <a href="#heart_beat">
                <span class="cs_tab_link_icon cs_center"><img src="{{asset('assets/img/icons/tab_link_icon_3.png')}}" alt="Icon"></span>
                <span>Our Story</span>
              </a>
            </li>
          </ul>
          <div class="cs_height_50 cs_height_lg_50"></div>
          <div class="tab-content">
            <div id="brain_althim" class="cs_tab active">
              <div class="cs_card cs_style_2">
                <div class="row cs_gap_y_30 align-items-xl-center">
                  <div class="col-lg-6">
                    <div class="cs_card_thumb cs_radius_5">
                      <img src="{{asset('assets/img/vision-mission.jpeg')}}" alt="Department Image">
                    </div>
                  </div>
                  <div class="col-lg-6">
                    <div class="cs_card_text">
                      <h2 class="cs_card_title">Mission and Vision</h2>
                      <p class="cs_card_subtitle">
                        At the Sindh Institute of Advanced Endoscopy and Gastroenterology (SIAG),
                      </p>
                      <p class="cs_card_subtitle">
                      our vision is to deliver equitable, innovative, and patient-centered
                      gastroenterological care. We aspire to transform.
                      </p>
                      <a href="{{ route('mission.vision') }}" class="cs_btn cs_style_1 cs_color_1">
                        <span>Read More </span>
                        <i class="fa-solid fa-angles-right"></i>
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div id="emergency" class="cs_tab">
              <div class="cs_card cs_style_2">
                <div class="row cs_gap_y_30 align-items-xl-center">
                  <div class="col-lg-6">
                    <div class="cs_card_thumb cs_radius_5">
                      <img src="{{asset('assets/img/leadership.jpeg')}}" alt="Department Image">
                    </div>
                  </div>
                  <div class="col-lg-6">
                    <div class="cs_card_text">
                      <h2 class="cs_card_title">Leadership</h2>
                      <p class="cs_card_subtitle">
                        At the heart of SIAG lies a simple yet powerful promise: to serve with
                        dignity, lead with knowledge, and heal with integrity. We’ve
                        reimagined what a public healthcare institute can look like
                      </p>
                      
                      <a href="{{ route('leadership') }}" class="cs_btn cs_style_1 cs_color_1">
                        <span>Read More </span>
                        <i class="fa-solid fa-angles-right"></i>
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div id="heart_beat" class="cs_tab">
              <div class="cs_card cs_style_2">
                <div class="row cs_gap_y_30 align-items-xl-center">
                  <div class="col-lg-6">
                    <div class="cs_card_thumb cs_radius_5">
                      <img src="{{asset('assets/img/our-story.jpeg')}}" alt="Department Image">
                    </div>
                  </div>
                  <div class="col-lg-6">
                    <div class="cs_card_text">
                      <h2 class="cs_card_title">Our Story</h2>
                      <p class="cs_card_subtitle">
                        The journey of the Sindh Institute of Advanced Endoscopy
                        and Gastroenterology (SIAG) began with a bold vision: to
                        bring world-class endoscopic care to the heart of Pakistan’s public healthcare system.
                      </p>
                      <a href="{{ route('our.story') }}" class="cs_btn cs_style_1 cs_color_1">
                        <span>Read More </span>
                        <i class="fa-solid fa-angles-right"></i>
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="cs_height_120 cs_height_lg_80"></div>
      <hr>
    </section>
    <!-- End Medical Tab Section -->
    <!-- Start Medical Solution Section -->
    <section class="cs_card cs_style_3 cs_gray_bg position-relative">
      <div class="cs_height_110 cs_height_lg_70"></div>
      <div class="container">
        <div class="row cs_gap_y_40">
          <div class="col-lg-6">
          <div class="cs_section_heading cs_style_1">
            <p class="cs_section_subtitle cs_accent_color">
              <span class="cs_shape_left"></span>CONTACT US
            </p>
            <h2 class="cs_section_title">Make An Appointment <br>Apply For Treatments</h2>
          </div>
          <div class="cs_height_25 cs_height_lg_25"></div>
          <form class="cs_contact_form row cs_gap_y_30 home_form_area" method="POST" action="{{ route('inquiries.store') }}">
            @csrf
            <input type="hidden" name="from_home" value="1">
            <div class="col-md-6">
              <input type="text" name="name" class="cs_form_field @error('name') is-invalid @enderror" placeholder="Your name *" value="{{ old('name') }}" required>
              @error('name')
                <span class="invalid-feedback">{{ $message }}</span>
              @enderror
            </div>
            <div class="col-md-6">
              <input type="email" name="email" class="cs_form_field @error('email') is-invalid @enderror" placeholder="Your email *" value="{{ old('email') }}" required>
              @error('email')
                <span class="invalid-feedback">{{ $message }}</span>
              @enderror
            </div>
            <div class="col-md-6">
              <input type="text" name="subject" class="cs_form_field @error('subject') is-invalid @enderror" placeholder="Your Subject" value="{{ old('subject') }}">
              @error('subject')
                <span class="invalid-feedback">{{ $message }}</span>
              @enderror
            </div>
            <div class="col-md-6">
              <input type="text" name="phone" class="cs_form_field @error('phone') is-invalid @enderror" placeholder="Your phone *" value="{{ old('phone') }}" required>
              @error('phone')
                <span class="invalid-feedback">{{ $message }}</span>
              @enderror
            </div>
            <div class="col-lg-12">
              <textarea rows="5" name="message" class="cs_form_field @error('message') is-invalid @enderror" placeholder="Your comments *" required>{{ old('message') }}</textarea>
              @error('message')
                <span class="invalid-feedback">{{ $message }}</span>
              @enderror
            </div>
            <div class="col-lg-12">
              <button type="submit" class="cs_btn cs_style_1 cs_color_1">Send Request</button>
            </div>
          </form>
          </div>
          <div class="col-lg-6">
            <div class="cs_solution_thumbnail cs_bg_filed" data-src="{{asset('assets/img/medical_solution_1.JPG')}}">
            </div>
          </div>
        </div>
      </div>
      <div class="cs_solution_shape position-absolute">
        <img src="{{asset('assets/img/stethoscope.png')}}" alt="Shape">
      </div>
      <div class="cs_height_120 cs_height_lg_80"></div>
    </section>

@endsection